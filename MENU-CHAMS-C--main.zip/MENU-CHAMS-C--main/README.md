# MENU-CHAMS-SOURCE

Source completo en C++ con ImGui y librerías necesarias.  

## 🚀 Instalación
1. Clona el repositorio:
   ```bash
   git clone https://github.com/Sao-Kirigaya/MENU-CHAMS-C-.git

Puedes descargar las librerías necesarias desde el sitio oficial:

## 📥 Descarga directa VCPKG
2. Clona el VCPKG:
   ```bash
   git clone https://github.com/microsoft/vcpkg.git
